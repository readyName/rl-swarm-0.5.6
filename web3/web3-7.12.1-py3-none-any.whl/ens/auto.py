from ens import (
    ENS,
)

ns = ENS()
