from web3 import (
    Web3,
)

w3 = Web3()
